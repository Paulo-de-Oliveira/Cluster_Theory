
##Paths and files
common_folder = "C:/Users/oliveipa/Dropbox/Cluster project - Clean/"
estimated_folder = "C:/wdsa_cluster_new/case_3flow/"
output_folder = "11_summary/demand_estimates_3flow"
estimated_file_prefix = "pat_mean_"
variance_file_prefix = "pat_var_"

output_folder = paste(common_folder, output_folder,
                         sep = "")

##The total should be 100 cluster cases
n_cluster_cases = 100

##SENM definitions
total_hours = 168
hour_begin = 336
clusters = 4


hour_range = hour_begin:(hour_begin + total_hours - 1)


for(cluster_case in 1:n_cluster_cases){

input_folder = paste(estimated_folder, cluster_case, sep="" )
setwd(input_folder)

estimated = NULL
variance = NULL

for(i in hour_range){
  
  ##Loading the pattern mean
  file_name = paste(estimated_file_prefix, i, ".csv", sep="" )
  pat_mean = read.csv(file_name, header = FALSE, sep = ",")
  estimated = rbind(estimated, pat_mean[,1])
  
  ##Loading the pattern variance
  file_name = paste(variance_file_prefix, i, ".csv", sep="" )
  pat_var = read.csv(file_name, header = FALSE, sep = ",")
  variance = rbind(variance, pat_var[,1])
  
}
  
##Changing the working directory
setwd(output_folder)
  
##Export the results
file_name = paste("estimated_", cluster_case,
                  ".csv", sep="")
write.table(estimated, file = file_name, 
            sep=",", row.names = FALSE,
            col.names = FALSE)
file_name = paste("variance_", 
                  cluster_case,
                  ".csv", sep="")
write.table(variance, file = file_name, 
            sep=",", row.names = FALSE,
            col.names = FALSE)
}






